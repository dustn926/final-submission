"""잘린 답변(finish_reason == "length", 2000토큰 한도에 걸림)을 엑셀 하나로 모아 직접 검토.

사용법
    python check_truncated.py            # → truncated_responses.xlsx

엑셀 열
    folder, model, item_id, attack_type, attack_name, position
    chars        : 답변 글자 수
    emoji_count  : 이모지 개수
    compress     : 압축률 (zlib 압축 후 크기 / 원래 크기). 낮을수록 같은 내용 반복 (0.15 미만이면 거의 확실히 반복)
    repetitive   : compress < 0.15 이면 True
    head / tail  : 답변 앞 300자 / 끝 300자 (반복인지 한눈에 보기용)
    response     : 답변 전체
시트: truncated(전체, 반복 의심 낮은 순 → 직접 볼 것부터), summary(모델 × 공격 유형 건수)
"""

import zlib
from pathlib import Path

import emoji
import pandas as pd
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

FOLDERS = ["results_process_attack_9to12", "results_process_attack_13to15"]   # BIPIA 9~12번, 13~15번
MODELS = ["qwen", "llama", "mistral"]
OUT = "truncated_responses.xlsx"
REPEAT_THRESHOLD = 0.15


def compress_ratio(text):
    b = text.encode("utf-8")
    return len(zlib.compress(b)) / len(b) if b else 1.0


rows = []
for folder in FOLDERS:
    for m in MODELS:
        path = Path(f"{folder}/{m}_attack.jsonl")
        if not path.exists():
            continue
        r = pd.read_json(path, lines=True)
        t = r[r.finish_reason == "length"].copy()
        t.insert(0, "folder", folder)
        rows.append(t)

df = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
if df.empty:
    raise SystemExit("잘린 답변이 없습니다.")

df["response"] = df["response"].fillna("").astype(str)
df["chars"] = df["response"].str.len()
df["emoji_count"] = df["response"].map(emoji.emoji_count)
df["compress"] = df["response"].map(compress_ratio).round(3)
df["repetitive"] = df["compress"] < REPEAT_THRESHOLD
df["head"] = df["response"].str[:300]
df["tail"] = df["response"].str[-300:]

cols = ["folder", "model", "item_id", "attack_type", "attack_name", "position",
        "chars", "emoji_count", "compress", "repetitive", "head", "tail", "response"]
out = df[cols].sort_values(["repetitive", "compress"], ascending=[True, False])   # 반복 아닌 것(직접 볼 것) 먼저
out = out.apply(lambda s: s.map(lambda v: ILLEGAL_CHARACTERS_RE.sub("", v) if isinstance(v, str) else v))

summary = df.pivot_table(index=["folder", "model"], columns="attack_type", values="item_id",
                         aggfunc="count", fill_value=0)
summary["합계"] = summary.sum(axis=1)
summary["반복 의심"] = df.groupby(["folder", "model"])["repetitive"].sum()

with pd.ExcelWriter(OUT) as w:
    out.to_excel(w, sheet_name="truncated", index=False)
    summary.to_excel(w, sheet_name="summary")

print(summary.to_string())
print(f"\n잘린 답변 {len(df)}개 중 반복 의심 {int(df.repetitive.sum())}개, "
      f"직접 볼 것(반복 아님) {int((~df.repetitive).sum())}개 → {OUT}")
