"""results_process_attack_*/ 의 답변 파일을 results_document_attacks_12672/ 과 같은 형식으로 맞춤 (채점 전에 한 번).

사용법
    python align_results.py

하는 일 (답변 내용·순서는 그대로, 형식만)
    1. 원본을 _original_responses/{결과 폴더}/ 에 백업 (이미 있으면 덮어쓰지 않음)
    2. *_attack.jsonl, *_clean.jsonl 각 행에 model_id, input_file 추가, 필드 순서를 document_attacks 와 같게
         model, model_id, input_file, kind, item_id, id, attack_type, attack_name, position, response, finish_reason, error
    3. 결과 폴더마다 input_manifest.json, generation_summary.csv, truncated_responses.xlsx 생성
       (truncated_responses.xlsx 는 폴더 맨 위의 truncated_responses.xlsx 를 폴더별로 나눈 것)
여러 번 실행해도 결과는 같음 (항상 백업한 원본에서 다시 만듦).
"""

import hashlib
import json
import shutil
from pathlib import Path

import pandas as pd

# 01_generate_responses.ipynb 실행 기록 기준 (Colab, /content/drive/MyDrive/bipia 에서 실행, llama 는 meta-llama 로 받음)
MODELS = {
    "qwen":    "Qwen/Qwen2.5-7B-Instruct",
    "llama":   "meta-llama/Llama-3.1-8B-Instruct",
    "mistral": "mistralai/Mistral-7B-Instruct-v0.3",
}
RUN_DIR = "/content/drive/MyDrive/bipia"
DATASETS = {   # 결과 폴더: 입력 엑셀
    Path("results_process_attack_9to12"): Path("IndustryBench_Process_Attack_9to12.xlsx"),
    Path("results_process_attack_13to15"): Path("IndustryBench_Process_Attack_13to15.xlsx"),
}
GEN_SETTINGS = {"temperature": 0, "max_tokens": 2000, "seed": 0}   # run_hf_models.py 설정
FIELDS = ["model", "model_id", "input_file", "kind", "item_id", "id", "attack_type", "attack_name", "position",
          "response", "finish_reason", "error"]
BACKUP = Path("_original_responses")
TRUNCATED_ALL = Path("truncated_responses.xlsx")


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def align_file(src, dst, input_file):
    rows = [json.loads(line) for line in open(src, encoding="utf-8")]
    out = []
    for r in rows:
        r = {**r, "model_id": MODELS[r["model"]], "input_file": input_file}
        extra = set(r) - set(FIELDS)
        if extra:
            raise SystemExit(f"{src}: 예상 못 한 필드 {extra}")
        out.append({k: r.get(k) for k in FIELDS})
    with open(dst, "w", encoding="utf-8") as f:
        for r in out:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    # 답변 내용이 바뀌지 않았는지 확인
    check = [json.loads(line) for line in open(dst, encoding="utf-8")]
    assert len(check) == len(rows)
    for a, b in zip(rows, check):
        assert all(a[k] == b[k] for k in a), f"{dst}: 값이 달라짐 ({a['item_id']})"
    return pd.DataFrame(out)


def main():
    truncated_all = pd.read_excel(TRUNCATED_ALL, sheet_name="truncated") if TRUNCATED_ALL.exists() else None

    for folder, xlsx in DATASETS.items():
        backup = BACKUP / folder
        if not backup.exists():
            backup.mkdir(parents=True)
            for p in sorted(folder.glob("*.jsonl")):
                shutil.copy2(p, backup / p.name)
            print(f"백업: {folder}/*.jsonl → {backup}/")
        input_file = f"{RUN_DIR}/{xlsx.name}"

        summary = []
        for src in sorted(backup.glob("*.jsonl")):
            df = align_file(src, folder / src.name, input_file)
            summary.append({"model": df["model"].iloc[0], "kind": df["kind"].iloc[0], "rows": len(df),
                            "truncated": int((df["finish_reason"] == "length").sum()),
                            "empty": int((df["response"].fillna("").str.strip() == "").sum())})
            print(f"  {folder / src.name}: {len(df)}행 정리")

        order = {m: i for i, m in enumerate(MODELS)}
        summary = sorted(summary, key=lambda r: (order[r["model"]], r["kind"] != "attack"))
        pd.DataFrame(summary).to_csv(folder / "generation_summary.csv", index=False, encoding="utf-8-sig")

        cases = pd.read_excel(xlsx, sheet_name="Attack_Cases", usecols=["attack_id"])
        clean = pd.read_excel(xlsx, sheet_name="Clean_QA", usecols=["source_id"])
        manifest = {"input_file": input_file, "input_sha256": sha256_file(xlsx),
                    "attack_rows": len(cases), "clean_rows": len(clean),
                    "models": MODELS, **GEN_SETTINGS}
        (folder / "input_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2),
                                                     encoding="utf-8")

        if truncated_all is not None:
            t = truncated_all[truncated_all["folder"] == folder.name]
            with pd.ExcelWriter(folder / "truncated_responses.xlsx") as w:
                t.to_excel(w, sheet_name="truncated", index=False)
                t.pivot_table(index="model", columns="attack_type", values="item_id", aggfunc="count",
                              fill_value=0).to_excel(w, sheet_name="summary")
        print(f"{folder}/: generation_summary.csv, input_manifest.json, truncated_responses.xlsx")


if __name__ == "__main__":
    main()
